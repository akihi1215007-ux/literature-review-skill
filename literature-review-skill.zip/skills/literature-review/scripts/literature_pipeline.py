#!/usr/bin/env python3
"""Offline, provenance-preserving literature library. No network or model calls."""
from __future__ import annotations

import argparse
from collections import defaultdict
import copy
import csv
import hashlib
import html
import io
import json
from pathlib import Path
import re
import sys
import unicodedata
from urllib.parse import unquote

SCHEMA = 1
FIELDS = ('title', 'authors', 'year', 'doi', 'arxiv_id', 'abstract', 'journal', 'url', 'type',
          'volume', 'issue', 'pages', 'publisher', 'isbn', 'issn', 'edition')
EXPORTS = ('records.csv', 'evidence.csv', 'screening.csv', 'review-map.md', 'references.bib', 'search-log.json')


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode('utf-8')).hexdigest()


def normalize_doi(value):
    value = unquote(str(value or '').strip())
    value = re.sub(r'^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)', '', value, flags=re.I).lower()
    if value and not re.fullmatch(r'10\.\d{4,9}/\S+', value):
        raise ValueError('Invalid DOI syntax; correct the input instead of silently discarding it')
    return value


def title_key(value):
    return re.sub(r'[^\w]+', ' ', unicodedata.normalize('NFKC', str(value or '')).lower()).strip()


def _authors(value):
    if isinstance(value, str):
        return value.strip()
    if value is None:
        return ''
    if not isinstance(value, list):
        raise ValueError('authors must be a string or list')
    names = []
    for author in value:
        if isinstance(author, str):
            names.append(author)
        elif isinstance(author, dict):
            family, given = author.get('family', ''), author.get('given', '')
            names.append((f'{family}, {given}' if given else family) or author.get('name', ''))
        else:
            raise ValueError('author list entries must be strings or name objects')
    return ' and '.join(x.strip() for x in names if x.strip())


def _context(value):
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError('search context must be an object')
    keep = ('query', 'source', 'retrieved_at', 'total_available', 'returned_count',
            'complete', 'warnings', 'endpoint', 'parameters', 'input_path')
    out = {k: copy.deepcopy(value[k]) for k in keep if k in value}
    if 'parameters' in out and isinstance(out['parameters'], dict):
        out['parameters'] = {k: v for k, v in out['parameters'].items()
                             if not any(s in k.lower() for s in ('key', 'token', 'secret', 'authorization'))}
    out.setdefault('complete', False)
    return out


def load_payload(payload):
    """Read normalized records, not raw Crossref/OpenAlex/other provider envelopes."""
    if isinstance(payload, list):
        return payload, {}
    if isinstance(payload, dict) and isinstance(payload.get('results'), list):
        return payload['results'], _context(payload)
    raise ValueError('Expected normalized JSON array or {results: [...]} search export')


def _normalise(item, context):
    if not isinstance(item, dict) or not any(k in item for k in ('title', 'doi', 'arxiv_id', 'source_id', 'pmid', 'openalex_id')):
        raise ValueError('Each record needs normalized bibliographic fields; raw provider envelopes are not records')
    row = {key: str(item.get(key) or '').strip() for key in FIELDS if key != 'authors'}
    row['authors'] = _authors(item.get('authors', item.get('author')))
    row['doi'] = normalize_doi(item.get('doi'))
    arxiv = re.sub(r'^(?:https?://(?:www\.)?arxiv\.org/(?:abs|pdf)/|arxiv:\s*)',
                   '', str(item.get('arxiv_id') or '').strip(), flags=re.I).removesuffix('.pdf')
    match = re.fullmatch(r'(\d{4}\.\d{4,5}|[A-Za-z][A-Za-z.\-]+/\d{7})(v\d+)?', arxiv)
    if arxiv and not match:
        raise ValueError('Invalid arXiv identifier')
    row['arxiv_id'] = match.group(1) if match else ''
    row['arxiv_versions'] = [arxiv] if arxiv else []
    related = item.get('related_doi') or ''
    # arXiv's DOI generally points to a separately published journal report.
    if row['arxiv_id'] and row['doi']:
        related = row['doi']
        row['doi'] = ''
    row['related_dois'] = [normalize_doi(related)] if related else []
    source = str(item.get('source') or context.get('source') or
                 ('openalex' if item.get('openalex_id') else 'pubmed' if item.get('pmid') else 'local-export'))
    source_id = str(item.get('source_id') or item.get('openalex_id') or item.get('pmid') or row['doi'] or arxiv or '')
    source_row = {
        'source': source, 'source_id': source_id,
        'query': item.get('query') or context.get('query', ''),
        'retrieved_at': item.get('retrieved_at') or context.get('retrieved_at', ''),
        'url': row['url'],
        'raw_metadata': copy.deepcopy(item.get('raw_metadata')),
        'metadata_basis': 'provider_response' if item.get('raw_metadata') is not None else 'normalized_export',
        'normalized_metadata': {k: row[k] for k in FIELDS},
    }
    if source_row['raw_metadata'] is None:
        source_row['imported_metadata'] = copy.deepcopy(item)
    source_row['observation_id'] = 'obs_' + fingerprint(source_row)[:24]
    row['sources'] = [source_row]
    return row


def _keys(row):
    keys = []
    if row.get('arxiv_id'):
        keys.append('arxiv:' + row['arxiv_id'])
    elif row.get('doi'):
        keys.append('doi:' + row['doi'])
    for src in row.get('sources', []):
        if src.get('source_id'):
            # arXiv versions share an arXiv identity; journal sources stay separate.
            if not row.get('arxiv_id'):
                keys.append('source:' + src['source'].lower() + ':' + src['source_id'])
    if not keys:
        keys.append('metadata:' + fingerprint({k: row.get(k) for k in FIELDS}))
    return keys


def _compatible(a, b):
    if bool(a.get('arxiv_id')) != bool(b.get('arxiv_id')):
        return False
    if a.get('arxiv_id') and b.get('arxiv_id') != a['arxiv_id']:
        return False
    return not (a.get('doi') and b.get('doi') and a['doi'] != b['doi'])


def _library(value=None):
    if value is None:
        return {'schema_version': SCHEMA, 'records': [], 'searches': [], 'candidate_duplicates': []}
    if (not isinstance(value, dict) or value.get('schema_version') != SCHEMA
            or not isinstance(value.get('records'), list)):
        raise ValueError('Expected a literature_pipeline library with supported schema_version')
    out = copy.deepcopy(value)
    ids = [r.get('record_id') for r in out['records']]
    if any(not x for x in ids) or len(ids) != len(set(ids)):
        raise ValueError('Library record_id values must be present and unique')
    out.setdefault('searches', [])
    out.setdefault('candidate_duplicates', [])
    return out


def merge_records(records, library=None, context=None):
    """Conservative identity merge. Title matches become candidates, not deletions."""
    if not isinstance(records, list):
        raise ValueError('records must be a list of normalized objects')
    out = _library(library)
    ctx = _context(context)
    if context:
        if ctx not in out['searches']:
            out['searches'].append(ctx)
    index = defaultdict(list)
    for existing in out['records']:
        for key in _keys(existing):
            index[key].append(existing)
    for item in records:
        incoming = _normalise(item, ctx)
        matches = {}
        for key in _keys(incoming):
            for match in index.get(key, []):
                if _compatible(match, incoming):
                    matches[match['record_id']] = match
                elif key.startswith('source:'):
                    raise ValueError('Conflicting source identity; reconcile DOI/provider metadata before importing')
        if len(matches) > 1:
            raise ValueError('Identity bridges several existing records; reconcile explicitly before importing')
        if matches:
            target = next(iter(matches.values()))
            for field in FIELDS:
                old, new = target.get(field, ''), incoming[field]
                if not old and new:
                    target[field] = new
                elif new and new != old:
                    conflict = {'field': field, 'kept': old, 'observed': new,
                                'source_ref': incoming['sources'][0]['observation_id']}
                    if conflict not in target['metadata_conflicts']:
                        target['metadata_conflicts'].append(conflict)
            for field in ('sources', 'arxiv_versions', 'related_dois'):
                for entry in incoming[field]:
                    if entry not in target[field]:
                        target[field].append(entry)
        else:
            target = incoming
            target['record_id'] = 'lit_' + fingerprint(_keys(incoming)[0])[:20]
            if any(r['record_id'] == target['record_id'] for r in out['records']):
                raise ValueError('Conflicting source identity; assign a corrected source_id explicitly')
            target.update({'metadata_conflicts': [], 'evidence': [], 'screening': []})
            out['records'].append(target)
        for key in _keys(target):
            if not any(r['record_id'] == target['record_id'] for r in index[key]):
                index[key].append(target)
    by_title = defaultdict(list)
    for record in out['records']:
        key = title_key(record.get('title'))
        if key:
            by_title[key].append(record['record_id'])
    out['candidate_duplicates'] = [{'record_ids': ids, 'reason': 'same_normalized_title; manual_identity_review'}
                                   for ids in by_title.values() if len(ids) > 1]
    doi_ids = {r['doi']: r['record_id'] for r in out['records'] if r.get('doi')}
    for record in out['records']:
        record['related_record_ids'] = sorted({doi_ids[d] for d in record['related_dois'] if d in doi_ids})
    return out


def _find(library, identifier):
    for record in library['records']:
        if record['record_id'] == identifier:
            return record
    raise ValueError('Unknown record_id')


def add_evidence(library, item):
    """Store one extraction or a batch, copying the library only once."""
    out = _library(library)
    for entry in item if isinstance(item, list) else [item]:
        _append_evidence(out, entry)
    return out


def _append_evidence(out, item):
    if not isinstance(item, dict):
        raise ValueError('Evidence must be an object or list of objects')
    evidence = copy.deepcopy(item)
    evidence.pop('evidence_id', None)
    for field in ('record_id', 'claim', 'locator', 'basis', 'finding', 'source_ref'):
        if not isinstance(evidence.get(field), str) or not evidence[field].strip():
            raise ValueError(f'Evidence requires nonempty {field}')
    record = _find(out, evidence['record_id'])
    if evidence['source_ref'] not in {s['observation_id'] for s in record['sources']}:
        raise ValueError('Evidence source_ref must identify an imported observation of this record')
    if evidence['basis'] == 'abstract':
        if re.search(r'\b(?:pages?|pp?\.?)\s*\d|第\s*\d+\s*页', evidence['locator'], re.I):
            raise ValueError('Abstract-only evidence cannot claim full-text page locations')
        observed = next(s for s in record['sources'] if s['observation_id'] == evidence['source_ref'])
        if not observed['normalized_metadata'].get('abstract'):
            raise ValueError('This observation has no supplied abstract')
    elif evidence['basis'] == 'full_text':
        document = Path(evidence.get('document_path') or '')
        if not document.is_file():
            raise ValueError('Full-text evidence requires an actually available local document_path')
        digest = hashlib.sha256()
        with document.open('rb') as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
        evidence['document_path'] = str(document.resolve())
        evidence['document_sha256'] = digest.hexdigest()
    else:
        raise ValueError('Evidence basis must be abstract or full_text')
    evidence.setdefault('support_status', 'unresolved')
    if evidence['support_status'] not in ('supported', 'contradicted', 'mixed', 'unresolved'):
        raise ValueError('Invalid support_status')
    # This is an extraction record, never an automatic source-support certificate.
    evidence.setdefault('verification_scope', 'source-bound extraction; claim support requires reading and judgment')
    evidence['evidence_id'] = 'ev_' + fingerprint(evidence)[:20]
    if not any(x['evidence_id'] == evidence['evidence_id'] for x in record['evidence']):
        record['evidence'].append(evidence)
    return out


def screen_records(library, items):
    out = _library(library)
    if not isinstance(items, list):
        raise ValueError('Screening input must be a list')
    for item in items:
        if not isinstance(item, dict):
            raise ValueError('Screening decision must be an object')
        row = copy.deepcopy(item)
        row.pop('decision_id', None)
        record = _find(out, row.get('record_id'))
        if row.get('stage') not in ('title_abstract', 'full_text'):
            raise ValueError('Screening stage must be title_abstract or full_text')
        if row.get('decision') not in ('include', 'exclude', 'uncertain', 'not_retrieved'):
            raise ValueError('Invalid screening decision')
        if row['decision'] in ('exclude', 'not_retrieved') and not str(row.get('reason') or '').strip():
            raise ValueError('Exclusion and not_retrieved require a reason')
        if not isinstance(row.get('reviewer'), str) or not row['reviewer'].strip():
            raise ValueError('Screening requires an actual reviewer identifier')
        if row['decision'] == 'not_retrieved' and row['stage'] != 'full_text':
            raise ValueError('not_retrieved is a full-text retrieval status')
        row['decision_id'] = 'decision_' + fingerprint(row)[:20]
        if not any(x['decision_id'] == row['decision_id'] for x in record['screening']):
            record['screening'].append(row)
    return out


def _csv(rows, fields):
    out = io.StringIO(newline='')
    writer = csv.DictWriter(out, fieldnames=fields, extrasaction='ignore')
    writer.writeheader()
    for row in rows:
        escaped = {}
        for key in fields:
            value = row.get(key, '')
            if isinstance(value, (list, dict)):
                value = json.dumps(value, ensure_ascii=False)
            # CSVs are often opened in Excel; preserve the data in the JSON library.
            if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@')):
                value = "'" + value
            escaped[key] = value
        writer.writerow(escaped)
    return out.getvalue()


def _bib_value(value):
    text = str(value).replace('\\', r'\textbackslash{}')
    # Preserve balanced capitalization braces, neutralize unmatched delimiters.
    depth, invalid = 0, False
    for char in text:
        depth += (char == '{') - (char == '}')
        if depth < 0:
            invalid = True
    if invalid or depth != 0:
        text = text.replace('{', r'\{').replace('}', r'\}')
    for char, replacement in (('&', r'\&'), ('%', r'\%'), ('#', r'\#')):
        text = text.replace(char, replacement)
    return text.replace('\r', ' ').replace('\n', ' ')


def _review_map(lib):
    records = lib['records']
    evidence = [x for r in records for x in r['evidence']]
    screening = [x for r in records for x in r['screening']]
    md = ['# 文献证据地图', '',
          '这是记录与提取的导出，不是穷尽检索、独立研究计数或自动支持性验证。', '',
          f'文献记录：{len(records)}；证据条目：{len(evidence)}；筛选决策：{len(screening)}。', '',
          '未确定的支持状态保留为 unresolved；检索截断和不确定决定必须在综合时披露。', '']
    for r in records:
        md += [f"## {r['record_id']}: {html.escape(r['title'] or '(无题名)')}", '',
               f"- Authors/year: {html.escape(r['authors'])} / {r['year'] or 'unknown'}",
               f"- DOI: {r['doi'] or 'none'}; arXiv: {r['arxiv_id'] or 'none'}",
               f"- Sources: {len(r['sources'])}; metadata conflicts: {len(r['metadata_conflicts'])}"]
        if not r['evidence']:
            md += ['- Evidence: not extracted; no full-text reading is implied.']
        for ev in r['evidence']:
            md += [f"- [{ev['basis']}; {ev['support_status']}] {html.escape(ev['claim'])}",
                   f"  - Finding: {html.escape(ev['finding'])}",
                   f"  - Locator: {html.escape(ev['locator'])}; source: {ev['source_ref']}"]
        for d in r['screening']:
            md += [f"- Screening: {d['stage']} / {d['decision']} / {html.escape(d['reviewer'])}; "
                   + html.escape(str(d.get('reason', '')))]
        md.append('')
    md += ['## 候选重复（尚未合并）', '',
           '```json', json.dumps(lib['candidate_duplicates'], ensure_ascii=False, indent=2), '```', '',
           '## 检索覆盖记录', '', '```json', json.dumps(lib['searches'], ensure_ascii=False, indent=2), '```', '']
    return '\n'.join(md)


def _bibliography(records):
    bib = []
    for r in records:
        # Stable library IDs avoid deleting distinct DOI reports with similar citekeys.
        kind = r.get('type') or ('misc' if r['arxiv_id'] else 'article')
        entry = {'proceedings-article': 'inproceedings', 'book-chapter': 'incollection',
                 'journal-article': 'article', 'review': 'article', 'preprint': 'misc',
                 'posted-content': 'misc', 'report': 'techreport', 'dissertation': 'phdthesis'}.get(kind, kind)
        if entry not in ('article', 'book', 'incollection', 'inproceedings', 'phdthesis', 'techreport', 'misc'):
            entry = 'misc'
        if r['arxiv_id']:
            entry = 'misc'
        lines = [f"@{entry}{{{r['record_id']},"]
        for field in ('authors', 'title', 'year', 'journal', 'doi', 'url', 'volume', 'issue', 'pages', 'publisher', 'isbn', 'issn', 'edition'):
            if r.get(field):
                bibfield = {'authors': 'author', 'issue': 'number'}.get(field, field)
                if field == 'journal' and entry in ('inproceedings', 'incollection'):
                    bibfield = 'booktitle'
                value = re.sub(r'(?<=\d)-(?=\d)', '--', r[field]) if field == 'pages' else r[field]
                lines.append(f"  {bibfield} = {{{_bib_value(value)}}},")
        if r['arxiv_id']:
            lines += [f"  eprint = {{{r['arxiv_id']}}},", '  archivePrefix = {arXiv},']
        lines.append('}')
        bib.append('\n'.join(lines))
    return '\n\n'.join(bib) + ('\n' if bib else '')


def export_library(library, only=None):
    """Render requested outputs; no selection preserves the six-file contract."""
    lib = _library(library)
    records = lib['records']
    render = {
        'records.csv': lambda: _csv(records, ['record_id', *FIELDS, 'arxiv_versions', 'related_dois',
                                     'related_record_ids', 'sources', 'metadata_conflicts']),
        'evidence.csv': lambda: _csv((x for r in records for x in r['evidence']), ['record_id', 'evidence_id', 'claim', 'basis', 'support_status',
                                      'finding', 'locator', 'source_ref', 'document_path', 'document_sha256',
                                      'verification_scope']),
        'screening.csv': lambda: _csv((x for r in records for x in r['screening']), ['record_id', 'decision_id', 'stage', 'decision', 'reviewer',
                                        'reason', 'study_id', 'decided_at']),
        'review-map.md': lambda: _review_map(lib),
        'references.bib': lambda: _bibliography(records),
        'search-log.json': lambda: json.dumps(lib['searches'], ensure_ascii=False, indent=2) + '\n',
    }
    if isinstance(only, str):
        raise ValueError('only must select filenames, not a single string')
    names = EXPORTS if only is None else tuple(only)
    if not names or any(name not in render for name in names):
        raise ValueError('only must select one or more known export filenames')
    return {name: render[name]() for name in names}


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def _write(path, content, overwrite=False):
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('w' if overwrite else 'x', encoding='utf-8', newline='') as stream:
        stream.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='command', required=True)
    for name in ('merge', 'evidence', 'screen'):
        command = subs.add_parser(name)
        command.add_argument('--input', type=Path, required=True, action='append' if name == 'merge' else 'store')
        command.add_argument('--library', type=Path, required=name != 'merge')
        command.add_argument('--output', type=Path, required=True)
        command.add_argument('--overwrite', action='store_true')
    command = subs.add_parser('export')
    command.add_argument('--library', type=Path, required=True)
    command.add_argument('--output-dir', type=Path, required=True)
    command.add_argument('--only', nargs='+', choices=EXPORTS, help='Render only selected files; default: all six')
    command.add_argument('--overwrite', action='store_true')
    args = parser.parse_args()
    try:
        if args.command == 'export':
            exports = export_library(_read(args.library), only=args.only)
            targets = [args.output_dir / name for name in exports]
            if not args.overwrite and any(p.exists() for p in targets):
                raise FileExistsError('Export files already exist; select a new folder or use --overwrite')
            for name, content in exports.items():
                _write(args.output_dir / name, content, args.overwrite)
            print(json.dumps({'exported_files': len(exports), 'scope': 'records and extraction, not claim validation'}))
            return
        if args.output.exists() and not args.overwrite:
            raise FileExistsError('Output exists; select a new path or use --overwrite')
        inputs = args.input if isinstance(args.input, list) else [args.input]
        if any(args.output.resolve() == p.resolve() for p in inputs):
            raise ValueError('Output must differ from all input imports')
        lib = _read(args.library) if args.library else None
        if args.command == 'merge':
            for path in inputs:
                rows, context = load_payload(_read(path))
                lib = merge_records(rows, library=lib, context=context)
        elif args.command == 'evidence':
            lib = add_evidence(lib, _read(args.input))
        else:
            lib = screen_records(lib, _read(args.input))
        _write(args.output, json.dumps(lib, ensure_ascii=False, indent=2) + '\n', args.overwrite)
        print(json.dumps({'records': len(lib['records']), 'candidate_groups': len(lib['candidate_duplicates'])}))
    except (OSError, ValueError, TypeError, KeyError) as exc:
        parser.exit(1, f'[FAIL] {exc}\n')


if __name__ == '__main__':
    main()
