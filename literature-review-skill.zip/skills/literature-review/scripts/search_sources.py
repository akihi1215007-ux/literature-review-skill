#!/usr/bin/env python3
"""Bounded public Crossref/arXiv search with traceable JSON output.

One page, at most 100 records. This is an exploratory sample, never a claim of
systematic-search completeness. No API keys are read and no PDFs are fetched.
Standard-library urllib uses normal TLS verification. --no-proxy affects only
this process's transport and never changes system or environment proxy settings.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import html
import json
import math
from pathlib import Path
import re
import ssl
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlencode
from urllib.request import ProxyHandler, Request, build_opener
import xml.etree.ElementTree as ET


ENDPOINTS = {
    "crossref": "https://api.crossref.org/works",
    "arxiv": "https://export.arxiv.org/api/query",
}
NS = {"atom": "http://www.w3.org/2005/Atom",
      "arxiv": "http://arxiv.org/schemas/atom",
      "opensearch": "http://a9.com/-/spec/opensearch/1.1/"}


class SearchError(RuntimeError):
    """A request or provider response failed; it is not an empty result set."""


class HTTPResponse:
    def __init__(self, status, headers, content):
        self.status_code, self.headers, self.content = status, headers, content

    @property
    def text(self):
        return self.content.decode("utf-8-sig")

    def json(self):
        return json.loads(self.text)


class HTTPTransport:
    """A local urllib opener; never installs a global opener or changes proxies."""
    def __init__(self, *, use_proxy=True):
        self.opener = build_opener(ProxyHandler() if use_proxy else ProxyHandler({}))
        self.last_arxiv_request = None

    def get(self, url, *, params, timeout):
        if url == ENDPOINTS["arxiv"]:
            if self.last_arxiv_request is not None:
                time.sleep(max(0.0, 3.0 - (time.monotonic() - self.last_arxiv_request)))
            self.last_arxiv_request = time.monotonic()
        request = Request(url + "?" + urlencode(params),
                          headers={"User-Agent": "LiteratureReviewSearch/1.0",
                                   "Accept": "application/json" if url == ENDPOINTS["crossref"] else "application/atom+xml"})
        try:
            with self.opener.open(request, timeout=timeout) as response:
                return HTTPResponse(response.status, response.headers, response.read())
        except HTTPError as error:
            # Preserve HTTP status for retry policy, without printing the URL.
            with error:
                return HTTPResponse(error.code, error.headers, error.read())


def _text(value):
    return " ".join(str(value or "").split())


def _doi(value):
    return unquote(re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "",
                         _text(value), flags=re.I)).lower()


def _retry_delay(response, attempt, now):
    value = response.headers.get("Retry-After") if response is not None else None
    if value:
        try:
            delay = float(value)
            if math.isfinite(delay):
                return max(0.0, delay)
        except (TypeError, ValueError):
            try:
                timestamp = parsedate_to_datetime(value)
                if timestamp.tzinfo is None:
                    timestamp = timestamp.replace(tzinfo=timezone.utc)
                return max(0.0, timestamp.timestamp() - now())
            except (TypeError, ValueError, OverflowError):
                pass
    return float(2 ** attempt)


def _request(session, source, params, sleep, now):
    for attempt in range(3):
        response = None
        try:
            response = session.get(ENDPOINTS[source], params=params, timeout=30)
        except (URLError, OSError, TimeoutError) as error:
            # Do not expose query URLs, proxy credentials, request headers or keys.
            tls_error = isinstance(error, ssl.SSLError) or isinstance(getattr(error, "reason", None), ssl.SSLError)
            if attempt == 2 or tls_error:
                raise SearchError(f"{source} transport failed ({type(error).__name__})") from None
        if response is not None:
            if response.status_code == 200:
                return response
            if response.status_code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise SearchError(f"{source} returned HTTP {response.status_code}")
        delay = _retry_delay(response, attempt, now)
        if delay > 60:
            raise SearchError(f"{source} requested Retry-After longer than 60 seconds; run again later")
        # arXiv retries are requests too: keep them at least three seconds apart.
        sleep(max(delay, 3.0 if source == "arxiv" else 0.0))
    raise SearchError(f"{source} request could not be completed")


def _first(record, field):
    values = record.get(field)
    return _text(values[0]) if isinstance(values, list) and values else ""


def _crossref(response, limit):
    try:
        payload = response.json()
        if not isinstance(payload, dict) or payload.get("status") != "ok":
            raise ValueError("missing success envelope")
        message = payload["message"]
        if not isinstance(message, dict) or not isinstance(message.get("items"), list):
            raise ValueError("missing work list")
        total = message["total-results"]
        if not isinstance(total, int) or isinstance(total, bool) or total < 0:
            raise ValueError("invalid total")
        records = []
        for item in message["items"][:limit]:
            if not isinstance(item, dict) or not isinstance(item.get("DOI"), str) or not item["DOI"].strip():
                raise ValueError("work DOI missing")
            authors = []
            for person in item.get("author") or []:
                if not isinstance(person, dict):
                    continue
                family, given = _text(person.get("family")), _text(person.get("given"))
                name = f"{family}, {given}" if family and given else family or _text(person.get("name")) or given
                if name:
                    authors.append(name)
            year = ""
            for date_field in ("published-print", "published-online", "published", "issued"):
                date = item.get(date_field) or {}
                parts = date.get("date-parts") if isinstance(date, dict) else None
                if isinstance(parts, list) and parts and isinstance(parts[0], list) and parts[0]:
                    year = str(parts[0][0])
                    break
            doi = _doi(item["DOI"])
            kind = item.get("type") or ""
            records.append({
                "source": "crossref", "source_id": doi, "doi": doi,
                "title": _first(item, "title"), "authors": " and ".join(authors),
                "year": year, "journal": _first(item, "container-title"),
                "type": {"journal-article": "article", "proceedings-article": "inproceedings",
                         "book": "book", "book-chapter": "incollection"}.get(kind, "misc"),
                "source_type": kind, "url": item.get("URL") or f"https://doi.org/{doi}",
                "abstract": _text(html.unescape(re.sub(r"<[^>]+>", " ", str(item.get("abstract") or "")))),
                "volume": _text(item.get("volume")), "issue": _text(item.get("issue")),
                "pages": _text(item.get("page")), "publisher": _text(item.get("publisher")),
                "isbn": _first(item, "ISBN"), "issn": _first(item, "ISSN"),
                "edition": _text(item.get("edition-number") or item.get("edition")),
                "metadata_basis": "provider_response", "raw_metadata": item,
            })
        if total < len(records) or (total > 0 and not records):
            raise ValueError("inconsistent work count")
        return records, total, payload
    except (ValueError, TypeError, KeyError, AttributeError) as error:
        raise SearchError(f"crossref response invalid ({type(error).__name__})") from None


def _arxiv(response, limit):
    try:
        root = ET.fromstring(response.content)
        if root.tag != f"{{{NS['atom']}}}feed":
            raise ValueError("expected Atom feed")
        total = int(root.findtext("opensearch:totalResults", "", NS))
        if total < 0:
            raise ValueError("invalid total")
        records = []
        for entry in root.findall("atom:entry", NS)[:limit]:
            entry_url = entry.findtext("atom:id", "", NS)
            if "/api/errors" in entry_url:
                raise ValueError("arXiv error entry")
            arxiv_id = re.sub(r"^https?://(?:export\.)?arxiv\.org/abs/", "", entry_url).strip()
            if not re.fullmatch(r"(?:\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7})(?:v\d+)?", arxiv_id):
                raise ValueError("arXiv identifier missing or malformed")
            match = re.search(r"(v\d+)$", arxiv_id)
            published = entry.findtext("atom:published", "", NS)
            records.append({
                "source": "arxiv", "source_id": arxiv_id, "arxiv_id": arxiv_id,
                "arxiv_base_id": re.sub(r"v\d+$", "", arxiv_id),
                "version": match.group(1) if match else "",
                # arXiv's DOI is a relation to a journal version, not this preprint's identity.
                "related_doi": _doi(entry.findtext("arxiv:doi", "", NS)),
                "title": _text(entry.findtext("atom:title", "", NS)),
                "authors": " and ".join(_text(author.findtext("atom:name", "", NS))
                                           for author in entry.findall("atom:author", NS)
                                           if _text(author.findtext("atom:name", "", NS))),
                "year": published[:4], "published": published,
                "updated": entry.findtext("atom:updated", "", NS), "type": "misc",
                "url": f"https://arxiv.org/abs/{arxiv_id}",
                "journal_ref": _text(entry.findtext("arxiv:journal_ref", "", NS)),
                "abstract": _text(entry.findtext("atom:summary", "", NS)),
                "metadata_basis": "provider_response",
                "raw_metadata": ET.tostring(entry, encoding="unicode"),
            })
        if total < len(records) or (total > 0 and not records):
            raise ValueError("inconsistent entry count")
        return records, total, response.text
    except (ET.ParseError, ValueError, TypeError, AttributeError, UnicodeError) as error:
        raise SearchError(f"arxiv response invalid ({type(error).__name__})") from None


def search_source(source, query, limit=20, *, session=None, sleep=time.sleep, now=time.time):
    """Return one traceable search envelope or raise; no partial/empty-on-error result."""
    if source not in ENDPOINTS:
        raise ValueError("source must be crossref or arxiv")
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100:
        raise ValueError("limit must be an integer between 1 and 100")
    if not isinstance(query, str) or not query.strip():
        raise ValueError("query must be nonempty text")
    params = ({"query": query, "rows": limit, "offset": 0} if source == "crossref" else
              {"search_query": query, "start": 0, "max_results": limit})
    session = session if session is not None else HTTPTransport()
    response = _request(session, source, params, sleep, now)
    records, total, raw = (_crossref if source == "crossref" else _arxiv)(response, limit)
    retrieved = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    for record in records:
        record["retrieved_at"] = retrieved
    return {"query": query, "source": source, "endpoint": ENDPOINTS[source],
            "parameters": params, "retrieved_at": retrieved,
            "returned_count": len(records), "total_available": total,
            "complete": False, "results": records,
            "warnings": ["One bounded page; not an exhaustive or systematic search.",
                         "Metadata and links do not establish full-text reading or claim support."],
            "raw_response": raw}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", choices=sorted(ENDPOINTS))
    parser.add_argument("query", help="Crossref text query or native arXiv query expression")
    parser.add_argument("--limit", type=int, default=20, help="Maximum records, 1-100 (default 20)")
    parser.add_argument("-o", "--output", type=Path, help="JSON output; default stdout")
    parser.add_argument("--overwrite", action="store_true", help="Explicitly replace an existing output")
    parser.add_argument("--no-proxy", action="store_true",
                        help="Ignore environment proxy settings for this transport; keep TLS verification")
    args = parser.parse_args(argv)
    if args.output and args.output.exists() and not args.overwrite:
        print("[FAIL] Output already exists; use another path or --overwrite", file=sys.stderr)
        return 2
    session = HTTPTransport(use_proxy=not args.no_proxy)
    try:
        envelope = search_source(args.source, args.query, args.limit, session=session)
        content = json.dumps(envelope, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            # Exclusive creation closes the race between the preflight check and write.
            with args.output.open("w" if args.overwrite else "x", encoding="utf-8") as handle:
                handle.write(content)
        else:
            print(content, end="")
    except (SearchError, ValueError, OSError) as error:
        print(f"[FAIL] {error}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
