# 引用格式与检查范围

只在用户要求排版/格式转换时加载。保留完整书目数据，用目标期刊要求或指定 CSL 排版；工具默认 BibTeX 是交换数据，不保证投稿格式。

## 选择样式

| 用户要求 | 核对依据 |
| --- | --- |
| APA | [官方示例](https://apastyle.apa.org/style-grammar-guidelines/references/examples) |
| Nature / Nature Portfolio | [具体期刊指南](https://www.nature.com/nature/for-authors/formatting-guide)，不把一家期刊规则套给全部子刊 |
| Chicago author-date | [官方指南](https://www.chicagomanualofstyle.org/tools_citationguide/citation-guide-2.html) |
| Vancouver / 医学编号制 | [NLM Citing Medicine](https://www.ncbi.nlm.nih.gov/books/NBK7256/)及目标期刊 |
| IEEE | [官方 reference guide](https://ieeeauthorcenter.ieee.org/wp-content/uploads/IEEE-Reference-Guide.pdf)及目标会刊 |

使用 Pandoc 时按[官方引用处理说明](https://pandoc.org/MANUAL.html#citations)提供实际 CSL 和完整书目。检查正文/书目键对应、作者截断、年份、题名大小写、期刊缩写、卷期页/文章号、DOI及编号顺序；缺字段回查来源，不补造。

格式正确、DOI 注册、作品身份、主张支持和当前状态分别报告。[检查工具](search_and_citation.md#bibtex-检查)只覆盖实际运行的检查范围；样式规则随目标版本核实，不以静态示例冒充当前投稿规定。
