# 检索、元数据与引用工具

命令以技能目录为工作目录，输出放项目新路径。使用 Python 3.10+；`citation_tools/` 的5个 CLI 及 `verify_citations.py` 需 `requests`（包括离线 BibTeX 检查）；`search_sources.py`、`literature_pipeline.py`、`search_databases.py` 用标准库。依赖/网络不可用时保留待核，继续现有材料；参数不明或版本变化时查对应 `--help`。

## 输出与兼容

`search_sources`、OpenAlex/PubMed 检索和 pipeline 默认拒绝覆盖；显式 `--overwrite` 才替换。`extract_metadata`、`doi_to_bibtex` 的 `--output` 和 `validate_citations` 的 `--report` 直接覆盖，须指定新路径。先创建输出父目录。

已有 `scripts/verify_citations.py` 保留 DOI 注册/元数据检查，`scripts/search_databases.py` 保留轻量导出兼容（只处理本地记录，不查数据库）。例如 `python scripts/verify_citations.py project/review.md -o project/doi-report.json`、`python scripts/search_databases.py project/results.json --format markdown --output project/papers.md`。它们不替代内容支持核读；需持久维护多源来源时用 pipeline。

## Crossref / arXiv：小规模发现

```text
python scripts/search_sources.py crossref "active noise control" --limit 20 -o project/crossref.json
python scripts/search_sources.py arxiv "all:acoustic AND all:control" --limit 20 -o project/arxiv.json
```

一次一页，limit 为1–100，始终 `complete: false`；无本地日期、start/cursor、sort 或全量选项。输出保留查询、UTC 时间、参数、实际返回数、服务总量（若有）、原始响应及规范化 results；arXiv 保留基ID/版本、published/updated 和相关 DOI。失败显式报错，不写伪零结果。`--no-proxy` 只让该进程直连，不改系统代理/TLS。

## OpenAlex

```text
python scripts/citation_tools/search_openalex.py "active noise control" --limit 50 --year-start 2020 --year-end 2026 --format json --output project/openalex.json
```

支持 `--type`、`--sort-by relevance|citations`、`--email`、`--format json|bibtex`；密钥放 `OPENALEX_API_KEY`，联系邮箱用 `OPENALEX_EMAIL` 或 `--email`。游标取回至 limit，每页最多100；重复游标/ID等错误显式失败。联系邮箱不保证配额，排序不代表质量。

OpenAlex/PubMed JSON 都含 source/query、UTC retrieved_at、parameters、returned_count、warnings 和 results，固定 `complete: false`、`total_available: null`；逐条 source_id 与 normalized_metadata/metadata_basis 是客户端快照，不是原始响应。需要完整覆盖时另存原始导出、实际查询/分页/总量诊断及截止理由。

## PubMed

```text
python scripts/citation_tools/search_pubmed.py "noise-induced hearing loss[Title/Abstract]" --date-start 2020/01/01 --date-end 2026/10/31 --limit 100 --output project/pubmed.json
```

支持位置查询或 `--query`，`--query-file` 优先；`--publication-types` 为逗号列表。日期拼为 Publication Date，单端缺省会用代码默认边界，最好显式给两端。环境可设 `NCBI_API_KEY`/`NCBI_EMAIL`，日志不存密钥。

单次 ESearch 最多取10,000 ID，再分批 EFetch，不是大集完整分页引擎。只解析 PubmedArticle；缺 PMID 或不支持的 book records 使该批失败且不写成功输出。失败与真实零结果可能同退出码1，查看 stderr；其中实际查询/日期边界/总量须按需保存。检索成功不表示获得全文。

## 标识符元数据 / DOI 转 BibTeX

```text
python scripts/citation_tools/extract_metadata.py --input project/identifiers.txt --format json --output project/metadata.json
python scripts/citation_tools/doi_to_bibtex.py --input project/dois.txt --output project/references.bib
```

`extract_metadata` 支持可重复 `--doi/--pmid/--pmcid/--arxiv/--url` 与 `--email`；input 为逐行标识符、数组或含 results/entries 的 JSON，每条取首个可用标识符。DOI 主要查 Crossref，缺记录不等于 DOI 不存在；URL 依赖可读取标签，PMCID 只解析关联身份，不下载全文。

`doi_to_bibtex` 用 doi.org 内容协商，支持位置 DOI、`--input`、`--delay`、`--format bibtex|json`。前者 JSON 为 `{count, entries}`（含 citation_key/bibtex），后者 entries 是 BibTeX 字符串，均不能直接当 pipeline results 合并。批量部分失败可写成功子集并退出2，核对请求/成功数和失败标识符。

## BibTeX 检查

```text
python scripts/citation_tools/validate_citations.py project/references.bib --manuscript project/review.md --report project/bib-check.json
```

默认离线查必要字段、年份/语法、作者分隔、重复键/DOI及相近题名；book 必须有非空白 author 或 editor。BibTeX 支持花括号/圆括号条目、嵌套花括号、带引号值、转义分隔符及单个裸 token；保留字段原值，不解释 TeX 或展开宏，`@string/@comment/@preamble` 不作为文献条目。拼接表达式 `#`、缺失分隔符/字段值等不支持或损坏的输入显式报错，不再把有效前缀当整文件成功。`parse_bibtex(text)` 对这些输入抛 `ValueError`；CLI/report 使用高严重度 `bibtex_parse_error` 并退出1。普通非条目文本可忽略，但其中的 `@` 会被视为条目开头；不解析条目内 `%` 注释。

`--manuscript` 支持 Pandoc 的 `@key`/`[@key1; @key2]`（键允许内部点，如 `foo.bar`，不含结尾标点）及常见 LaTeX `\cite*`/`\citep`/`\citet`/`\textcite`/`\parencite`/`\autocite`，可有星号、最多两组不嵌套的可选方括号、逗号分隔多个键。忽略 HTML 注释、配对的 Markdown 反引号/波浪线围栏、行内反引号代码、LaTeX verbatim/lstlisting/minted 和 `\verb` 代码；`.tex/.ltx/.latex` 才把未转义 `%` 后的文本作为注释，Markdown 的百分号保留。排除普通邮箱地址；纯数字 Pandoc 键不计入。

这是有限语法检查，不覆盖 Word 域、自定义宏/条件编译、完整 Markdown/TeX 语法或引用语义。已识别引用命令若含嵌套方括号、缺失参数或 `\cites/\parencites/\textcites/\autocites` 多组参数，显式报告 `manuscript_parse_error`；这些语法须另用对应工具检查。缺失/不可解码稿件报告 `manuscript_read_error`。两类错误均保留 `checked: false`，不生成 unused/实际引用数量判断，退出1；直接调用 `parse_manuscript_citations` 分别抛读取异常或 `ValueError`。真正空稿件仍为 `checked: true`、空 cited_keys，可正常产生 unused 提醒。

`--check-dois` 才联网，依次 Crossref → 适用时 DataCite → 不跟随出版商跳转的 DOI resolver；超时/限流保留未决。作者预览至多前三人加 et al.，不作完整著录依据。`--venue` 仅内置经验提醒，`--min-count` 仅用户明确要求时设置。errors 导致退出1，退出0仍须查看 duplicates/warnings；检查不自动覆盖主张支持或完整撤稿现态。

## 需要文献库时

```text
python scripts/literature_pipeline.py merge --input project/openalex.json --input project/crossref.json --output project/library-v1.json
python scripts/literature_pipeline.py evidence --library project/library-v1.json --input project/evidence-items.json --output project/library-v2.json
python scripts/literature_pipeline.py export --library project/library-v2.json --output-dir project/delivery --only references.bib evidence.csv
```

`evidence` 接受单对象或数组；`export` 不带 `--only` 时仍导六文件。输入/版本/来源语义以 [library_schema.md](library_schema.md) 为准；不用建库的任务可直接交付。保留原输出，不能把 provider envelope、entries 或 BibTeX 字符串冒充规范化 results。合并后以库 record_id 核引用键，证据版本与实际引用 URL 一致。
