# 文献库与证据合同

`literature_pipeline.py` 纯离线，不自动验证主张、全文身份或研究数量。

## 输入

接受归一化数组，或 `{results: [...], source, query, retrieved_at, total_available, complete}`；不接受原始 Crossref `message.items` 等 envelope。保留原始输出，并由检索脚本或明确适配过程归一化。

```json
{
  "source": "local-export", "query": "acoustic control", "complete": false,
  "results": [{
    "title": "Synthetic example, not a real paper",
    "authors": ["Li, A.", "Chen, B."], "year": 2026,
    "doi": "10.1234/example", "source_id": "local-001",
    "url": "https://example.invalid/paper",
    "abstract": "Synthetic abstract for a test fixture.",
    "raw_metadata": {"fixture": true}
  }]
}
```

authors 支持字符串、字符串数组或姓名对象数组。BibTeX 作者之间用 `and`；多个作者的分号原文应先规范，避免被当成一个作者。

## 身份与合并

- library 使用 schema_version=1，含 records、searches、candidate_duplicates。
- 规范 DOI、arXiv 基ID或一致 provider/source_id 匹配身份；补 DOI 不改已有 record_id。
- 同题名不自动合并不同 DOI。无强身份的不同来源保留分开，仅列候选。空题名不是重复键。
- arXiv 版本保存在 arxiv_versions；其期刊 DOI 保存 related_dois。期刊记录保持独立，由 related_record_ids 关联。
- 新记录桥接多个既有编号时停止，先明确整理，不静默搬移证据。
- 每次来源观察含 observation_id、source、source_id、query、retrieved_at、metadata_basis、normalized_metadata。确实提供原始响应才保存 raw_metadata；只有归一化导出时该值为 null，完整输入保存 imported_metadata，不冒充原始 API 响应。同批重放不翻倍，不同日期/内容保留快照。
- 首个有效元数据作默认，不一致保存 metadata_conflicts；这不是自动裁定哪方正确。

## 证据

从库读取真实 record_id、sources.observation_id 后填写：

```json
{
  "record_id": "FROM_LIBRARY", "source_ref": "FROM_RECORD_SOURCES",
  "claim": "待核命题", "basis": "abstract",
  "locator": "Abstract, sentence 2", "finding": "实际报告内容及条件",
  "support_status": "unresolved"
}
```

basis 只可 abstract/full_text。摘要证据要求该观察实际含摘要，不能标全文页码。
全文证据需 document_path 指向实际本地文件，locator 为章节/表图/公式/页码；脚本计算 document_sha256。
hash 只标识材料，不证明与记录相符、定位正确或支持命题，读取者仍须核对。
远端全文先合法取得和阅读，不能只填 PDF 链接。

support_status 可 supported/contradicted/mixed/unresolved，默认 unresolved；这是提取者声明，不是脚本科学认证。JSON 内可另附条件、局限和判定者；未报告不补数字。

## 筛选

```json
[{
  "record_id": "FROM_LIBRARY", "stage": "full_text",
  "decision": "not_retrieved", "reviewer": "actual-reviewer",
  "reason": "目前只有摘要，全文未取得"
}]
```

stage 为 title_abstract/full_text；decision 为 include/exclude/uncertain/not_retrieved。
exclude/not_retrieved 必须理由，not_retrieved 只用于全文阶段。不会补造第二评审人。
决定保留历史，历史行数不是筛选数。实际确认同研究后可填 study_id；脚本不自动输出 PRISMA 纳入研究数或裁定多评审一致性。

## 命令与导出

- merge --input FILE 可重复，--library 可选，--output 写新版本。
- evidence --library FILE --input ITEM.json --output FILE：输入单个对象或对象数组。批量一次校验、一次复制库、一次写入；任一项失败不写部分结果。原单条接口保持可用。
- screen --library FILE --input DECISIONS.json --output FILE 一次加一批决定。
- export --library FILE --output-dir NEW_DIR 默认导出六个文件；--only references.bib evidence.csv 等仅计算并写入指定文件。普通查找/精读可以直接交付，不要求先建库。
- 默认拒绝覆盖，确需替换须显式 --overwrite；导入 JSON 不作为输出。
- BibTeX key 用 record_id，不因同作者同年误删不同论文；不是最终期刊排版。
- JSON 是完整事实记录；CSV 公式型单元格加前导引号，避免 Excel 将文献文本解释为公式。

证据地图不替代综述正文；最后仍按主题综合，披露覆盖、材料可得性和未解决项。
