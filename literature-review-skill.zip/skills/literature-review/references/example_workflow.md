# 离线数据流示例

仅在调试文献库时阅读。以下为合成材料，无真实论文或联网检索；普通查找不必运行本例。
在技能目录用配置的 Python 运行以下代码，输出目录必须尚不存在：

```python
import json
from pathlib import Path
import sys
sys.path.insert(0, 'scripts')
from literature_pipeline import merge_records, add_evidence, export_library

library = merge_records([{
    'title': 'SYNTHETIC: measurement reporting', 'source_id': 'fixture-001',
    'source': 'synthetic-fixture', 'abstract': 'Synthetic text: report measurement settings.'
}])
record = library['records'][0]
library = add_evidence(library, [{
    'record_id': record['record_id'], 'source_ref': record['sources'][0]['observation_id'],
    'claim': 'The fixture mentions reporting settings.', 'basis': 'abstract',
    'locator': 'Synthetic abstract, sentence 1', 'finding': 'Report measurement settings.'
}])
out = Path('project/synthetic-demo')
out.mkdir(parents=True, exist_ok=False)
(out / 'library.json').write_text(json.dumps(library, ensure_ascii=False, indent=2), encoding='utf-8')
for name, content in export_library(library, only=['evidence.csv', 'review-map.md']).items():
    (out / name).write_text(content, encoding='utf-8')
```

编号从库中读取，证据默认 unresolved。两个导出来自同一库；库、CSV 和 Markdown 内容应对应。
实际字段、全文材料要求与默认六文件兼容见 [library_schema.md](library_schema.md)。
