# Third-party notices

## Scientific Agent Skills — K-Dense Inc.

This project includes modified material from the `literature-review` and
`citation-management` skills in [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills).

- Upstream revision: `a1043ef544e3a100c28e70a736b6cf32554d0677`
- License: MIT; full original terms are included in [LICENSE](LICENSE).
- Copyright (c) 2025 K-Dense Inc.
- [Pinned upstream license](https://github.com/K-Dense-AI/scientific-agent-skills/blob/a1043ef544e3a100c28e70a736b6cf32554d0677/LICENSE.md)

Derived literature-review material includes `SKILL.md`, `assets/review_template.md`,
the citation styles, core workflow, database strategies, example workflow and
search/citation references, and `scripts/search_databases.py` and `scripts/verify_citations.py`.

Imported citation-management material under `scripts/citation_tools/`:
`_common.py`, `search_openalex.py`, `search_pubmed.py`, `extract_metadata.py`,
`doi_to_bibtex.py`, and `validate_citations.py`.

Integration changes include a shorter task-specific entry point, revised
references, citation search adapters, a provenance-preserving library, bounded
public search, batch evidence handling, selected exports, and offline tests.
This project is an independent integration, not an official K-Dense product.

## Method references

Reading, evidence extraction, screening and incremental-update guidance was
independently written with reference to general methods discussed in these
projects. Their code or substantial template text is not included or relicensed:

- [xiaofengShi/paper-reading-skill](https://github.com/xiaofengShi/paper-reading-skill)
  — reading scope, mechanisms and evidence location; MIT.
- [HuiyuanXie/academic-research-skills](https://github.com/HuiyuanXie/academic-research-skills)
  — type-aware extraction and update concepts; license not confirmed.
- [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills)
  — traceable screening and evidence methods; CC BY-NC 4.0.
- [Yuan1z0825/nature-skills](https://github.com/Yuan1z0825/nature-skills)
  — metadata versus claim-support distinction; Apache-2.0.

These references do not grant a combined MIT license to those external projects.
Their authors' papers are not automatically added to a user's bibliography.

## External APIs

Clients access provider-operated services when explicitly run:
[Crossref](https://www.crossref.org/documentation/retrieve-metadata/rest-api/),
[arXiv](https://info.arxiv.org/help/api/user-manual.html),
[OpenAlex](https://docs.openalex.org/), and [NCBI](https://www.ncbi.nlm.nih.gov/books/NBK25501/).
Availability, credentials, permissions and limits remain provider-specific.
