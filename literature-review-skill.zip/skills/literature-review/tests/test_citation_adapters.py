"""Offline regression tests for copied source CLIs and library interoperability."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock


SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_cli(module, arguments):
    with mock.patch.object(sys, "argv", [module.__file__, *arguments]):
        try:
            result = module.main()
            return result if result is not None else 0
        except SystemExit as error:
            return error.code


@unittest.skipUnless(importlib.util.find_spec("requests"), "optional citation adapters require requests")
class CitationAdapterTests(unittest.TestCase):
    def modules(self):
        for name, source, class_name, id_field, source_id in (
                ("search_openalex", "openalex", "OpenAlexSearcher", "openalex_id", "https://openalex.org/W123"),
                ("search_pubmed", "pubmed", "PubMedSearcher", "pmid", "12345678")):
            yield (load_module(name + "_test", SCRIPTS / "citation_tools" / (name + ".py")),
                   source, class_name, id_field, source_id)

    def test_existing_output_is_rejected_before_constructing_network_client(self):
        for module, source, class_name, _, _ in self.modules():
            with self.subTest(source=source), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "search.json"
                output.write_text("preserved", encoding="utf-8")
                with mock.patch.object(module, class_name, return_value=SimpleNamespace(search=lambda *args, **kwargs: [])) as client, contextlib.redirect_stderr(io.StringIO()):
                    self.assertNotEqual(run_cli(module, ["query", "-o", str(output)]), 0)
                    client.assert_not_called()
                self.assertEqual(output.read_text(encoding="utf-8"), "preserved")

    def test_json_export_identifies_source_and_preserves_normalized_snapshot(self):
        pipeline = load_module("pipeline_for_adapter_test", SCRIPTS / "literature_pipeline.py")
        for module, source, class_name, id_field, source_id in self.modules():
            record = {id_field: source_id, "doi": "", "title": "A real normalized shape",
                      "authors": "Smith, Ada", "year": "2024", "journal": "Journal",
                      "volume": "9", "issue": "2", "pages": "11-21", "abstract": "Supplied abstract."}
            client = SimpleNamespace(search=lambda *args, **kwargs: [source_id] if source == "pubmed" else [record],
                                     fetch_metadata=lambda pmids: [record])
            with self.subTest(source=source), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "search.json"
                output.write_text("replace only by explicit option", encoding="utf-8")
                with mock.patch.object(module, class_name, return_value=client), contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(run_cli(module, ["query", "--limit", "1", "-o", str(output), "--overwrite"]), 0)
                envelope = json.loads(output.read_text(encoding="utf-8"))
                self.assertEqual(envelope["source"], source)
                self.assertEqual(envelope["returned_count"], 1)
                self.assertFalse(envelope["complete"])
                self.assertTrue(envelope["retrieved_at"].endswith("Z"))
                self.assertEqual(envelope["parameters"]["max_results"], 1)
                self.assertTrue(envelope["warnings"])
                self.assertNotIn("api_key", envelope["parameters"])
                exported = envelope["results"][0]
                self.assertEqual(exported["source"], source)
                self.assertEqual(exported["source_id"], source_id)
                self.assertEqual(exported["normalized_metadata"]["volume"], "9")
                self.assertNotIn("raw_metadata", exported, "normalized client data is not a raw API response")
                self.assertIn("normalized", exported["metadata_basis"])
                rows, context = pipeline.load_payload(envelope)
                library = pipeline.merge_records(rows, context=context)
                corrected = dict(exported, title="Corrected normalized title")
                updated = pipeline.merge_records([corrected], library=library, context=context)
                self.assertEqual(len(updated["records"]), 1)
                self.assertEqual(updated["records"][0]["record_id"], library["records"][0]["record_id"])


if __name__ == "__main__":
    unittest.main()
