"""Offline contract tests; all HTTP and waiting are replaced at the boundary."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "search_sources.py"


def load_search_module(testcase):
    testcase.assertTrue(SCRIPT.is_file(), "bounded public search implementation is missing")
    spec = importlib.util.spec_from_file_location("search_sources_under_test", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Response:
    def __init__(self, status=200, payload=None, text="", headers=None):
        self.status_code = status
        self._payload = payload
        self.text = text
        self.content = text.encode("utf-8")
        self.headers = headers or {}

    def json(self):
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


class Session:
    def __init__(self, *outcomes):
        self.outcomes = list(outcomes)
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        outcome = self.outcomes.pop(0)
        if isinstance(outcome, Exception):
            raise outcome
        return outcome


CROSSREF = {
    "status": "ok", "message-type": "work-list", "message-version": "1.0.0",
    "message": {"total-results": 57, "items-per-page": 1,
                "query": {"start-index": 0, "search-terms": "spectral modelling"},
                "items": [{"DOI": "10.1234/AbC", "type": "journal-article",
                           "title": ["Spectral modelling"],
                           "author": [{"given": "Ada", "family": "Smith"},
                                      {"name": "A Working Group"}],
                           "published": {"date-parts": [[2024, 2, 3]]},
                           "container-title": ["Journal of Signals"],
                           "URL": "https://doi.org/10.1234/AbC",
                           "abstract": "<jats:p>Test abstract.</jats:p>",
                           "link": [{"URL": "https://example.org/full.pdf"}]}]},
}

ARXIV = '''<?xml version="1.0"?>
<feed xmlns="http://www.w3.org/2005/Atom"
 xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/"
 xmlns:arxiv="http://arxiv.org/schemas/atom">
 <id>https://arxiv.org/api/test</id><title>arXiv query</title>
 <opensearch:totalResults>28</opensearch:totalResults>
 <opensearch:startIndex>0</opensearch:startIndex>
 <opensearch:itemsPerPage>1</opensearch:itemsPerPage>
 <entry><id>http://arxiv.org/abs/2401.12345v2</id>
 <published>2024-01-20T12:00:00Z</published><updated>2024-03-01T12:00:00Z</updated>
 <title>A spectral\n model</title><summary>A test summary.</summary>
 <author><name>Ada Smith</name></author><arxiv:doi>10.1234/JOURNAL</arxiv:doi>
 <arxiv:journal_ref>Journal of Signals 2, 1 (2024)</arxiv:journal_ref>
 <link rel="alternate" href="http://arxiv.org/abs/2401.12345v2"/>
 <link title="pdf" type="application/pdf" href="http://arxiv.org/pdf/2401.12345v2"/>
 <category term="cs.LG"/>
 </entry></feed>'''


class SearchSourcesTests(unittest.TestCase):
    def test_crossref_book_keeps_publisher_isbn_and_edition_for_bibliography(self):
        module = load_search_module(self)
        payload = copy.deepcopy(CROSSREF)
        payload["message"]["items"][0].update({
            "type": "book", "publisher": "Example Academic Press",
            "ISBN": ["978-1-23456-789-0"], "edition-number": "2",
            "volume": "4", "issue": "2", "page": "11-21",
        })
        record = module.search_source("crossref", "spectral modelling", limit=1,
                                      session=Session(Response(payload=payload)))["results"][0]
        self.assertEqual(record["type"], "book")
        self.assertEqual(record.get("publisher"), "Example Academic Press")
        self.assertEqual(record.get("isbn"), "978-1-23456-789-0")
        self.assertEqual(record.get("edition"), "2")
        self.assertEqual(record["volume"], "4")
        self.assertEqual(record["issue"], "2")
        self.assertEqual(record["pages"], "11-21")

    def test_crossref_search_keeps_traceable_record_and_bounded_query(self):
        module = load_search_module(self)
        session = Session(Response(payload=CROSSREF))
        result = module.search_source("crossref", "spectral modelling", limit=1, session=session)
        self.assertEqual(result["returned_count"], 1)
        self.assertEqual(result["total_available"], 57)
        self.assertFalse(result["complete"])
        self.assertEqual(result["source"], "crossref")
        self.assertEqual(result["query"], "spectral modelling")
        record = result["results"][0]
        self.assertEqual(record["doi"], "10.1234/abc")
        self.assertEqual(record["authors"], "Smith, Ada and A Working Group")
        self.assertEqual(record["year"], "2024")
        self.assertEqual(record["abstract"], "Test abstract.")
        self.assertEqual(record["raw_metadata"]["DOI"], "10.1234/AbC")
        self.assertTrue(result["retrieved_at"].endswith("Z"))
        self.assertTrue(result["warnings"])
        endpoint, request = session.calls[0]
        self.assertEqual(endpoint, "https://api.crossref.org/works")
        self.assertEqual(request["params"]["rows"], 1)
        self.assertEqual(request["params"]["query"], "spectral modelling")
        self.assertGreater(request["timeout"], 0)
        self.assertNotEqual(request.get("verify"), False)

    def test_arxiv_versions_are_identity_and_journal_doi_is_relation(self):
        module = load_search_module(self)
        session = Session(Response(text=ARXIV))
        result = module.search_source("arxiv", "all:spectral", limit=1, session=session)
        record = result["results"][0]
        self.assertEqual(record["arxiv_id"], "2401.12345v2")
        self.assertEqual(record["arxiv_base_id"], "2401.12345")
        self.assertEqual(record["version"], "v2")
        self.assertEqual(record["related_doi"], "10.1234/journal")
        self.assertFalse(record.get("doi"))
        self.assertEqual(record["title"], "A spectral model")
        self.assertEqual(result["total_available"], 28)
        self.assertIn("<", record["raw_metadata"])
        self.assertEqual(len(session.calls), 1, "search must not fetch the linked PDF")

    def test_retries_429_at_most_three_attempts_and_honors_delay(self):
        module = load_search_module(self)
        session = Session(*(Response(status=429, headers={"Retry-After": "4"}) for _ in range(3)))
        waits = []
        with self.assertRaises(module.SearchError):
            module.search_source("crossref", "x", session=session, sleep=waits.append)
        self.assertEqual(len(session.calls), 3)
        self.assertEqual(waits, [4.0, 4.0])

    def test_long_retry_after_stops_without_retrying_early(self):
        module = load_search_module(self)
        session = Session(Response(status=429, headers={"Retry-After": "600"}))
        waits = []
        with self.assertRaises(module.SearchError):
            module.search_source("crossref", "x", session=session, sleep=waits.append)
        self.assertEqual(len(session.calls), 1)
        self.assertEqual(waits, [])

    def test_http_date_retry_after_is_respected(self):
        module = load_search_module(self)
        session = Session(Response(status=503, headers={"Retry-After": "Wed, 21 Oct 2015 07:28:05 GMT"}),
                          Response(payload=CROSSREF))
        waits = []
        module.search_source("crossref", "x", limit=1, session=session,
                             sleep=waits.append, now=lambda: 1445412480.0)
        self.assertEqual(waits, [5.0])

    def test_failures_cannot_become_successful_empty_search(self):
        module = load_search_module(self)
        outcomes = [Response(status=403), Response(payload={}),
                    Response(payload=ValueError("bad JSON")), Response(text="<broken"),
                    Response(text=ARXIV.replace("http://arxiv.org/abs/2401.12345v2",
                                                "http://arxiv.org/api/errors#bad"))]
        for source, outcome in zip(["crossref"] * 3 + ["arxiv"] * 2, outcomes):
            with self.subTest(source=source, outcome=outcome.status_code):
                with self.assertRaises(module.SearchError):
                    module.search_source(source, "x", session=Session(outcome))

    def test_valid_zero_results_remains_distinct_from_error(self):
        module = load_search_module(self)
        response = Response(payload={"status": "ok", "message": {"total-results": 0, "items": []}})
        result = module.search_source("crossref", "none", session=Session(response))
        self.assertEqual(result["returned_count"], 0)
        self.assertEqual(result["total_available"], 0)
        self.assertFalse(result["complete"])

    def test_cli_refuses_existing_output_before_network_and_no_proxy_is_local(self):
        module = load_search_module(self)
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "search.json"
            target.write_text("original", encoding="utf-8")
            with mock.patch.object(module, "search_source") as search, contextlib.redirect_stderr(io.StringIO()):
                self.assertNotEqual(module.main(["crossref", "x", "-o", str(target)]), 0)
                search.assert_not_called()
            self.assertEqual(target.read_text(encoding="utf-8"), "original")
            target.unlink()
            with mock.patch.object(module, "HTTPTransport") as factory, contextlib.redirect_stdout(io.StringIO()):
                session = Session(Response(payload=CROSSREF))
                factory.return_value = session
                self.assertEqual(module.main(["crossref", "x", "--limit", "1", "--no-proxy", "-o", str(target)]), 0)
                self.assertFalse(factory.call_args.kwargs["use_proxy"])
            self.assertEqual(json.loads(target.read_text(encoding="utf-8"))["returned_count"], 1)

    def test_invalid_limits_or_sources_do_not_make_requests(self):
        module = load_search_module(self)
        for source, limit in [("crossref", 0), ("crossref", 101), ("other", 1)]:
            with self.subTest(source=source, limit=limit):
                session = Session()
                with self.assertRaises(ValueError):
                    module.search_source(source, "x", limit=limit, session=session)
                self.assertEqual(session.calls, [])


if __name__ == "__main__":
    unittest.main()
