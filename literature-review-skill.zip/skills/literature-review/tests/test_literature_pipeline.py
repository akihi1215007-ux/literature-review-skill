"""Offline contract tests for the literature evidence library.

These fixtures are synthetic bibliographic records, not scientific findings.
No network, PDF renderer, or external provider is used.
"""

import csv
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from literature_pipeline import (  # noqa: E402
    add_evidence,
    export_library,
    load_payload,
    merge_records,
    screen_records,
)


def imported_record(**overrides):
    """A complete small observation; callers state the identity change."""
    record = {
        "title": "Causal {FFT} control for duct noise",
        "authors": ["Li, A.", "Chen, B."],
        "year": 2026,
        "doi": "10.1234/anc.1",
        "source": "local-export",
        "source_id": "export-001",
        "query": "active noise control",
        "retrieved_at": "2026-11-02T08:00:00+08:00",
        "url": "https://example.invalid/paper-1",
        "abstract": "A controller was evaluated in a duct. Robustness was not reported.",
        "raw_metadata": {"provider_marker": "local-proof"},
    }
    record.update(overrides)
    return record


def one_record_library():
    return merge_records([imported_record()])


def evidence_for(library, **overrides):
    record = library["records"][0]
    item = {
        "record_id": record["record_id"],
        "claim": "The abstract describes a duct evaluation.",
        "locator": "Abstract, sentence 1",
        "basis": "abstract",
        "finding": "A controller was evaluated in a duct.",
        "source_ref": record["sources"][0]["observation_id"],
    }
    item.update(overrides)
    return item


class LiteraturePipelineTests(unittest.TestCase):
    def test_selected_export_accepts_iterators_and_rejects_empty_selection(self):
        library = one_record_library()
        self.assertEqual(export_library(library, only=iter(['references.bib'])),
                         {'references.bib': export_library(library)['references.bib']})
        with self.assertRaises(ValueError):
            export_library(library, only=iter([]))

    def test_batch_evidence_matches_single_updates_and_keeps_input_unchanged(self):
        library = one_record_library()
        items = [evidence_for(library), evidence_for(library, claim='Another question',
                                                   finding='Robustness was not reported.')]
        expected = add_evidence(add_evidence(library, items[0]), items[1])
        self.assertEqual(add_evidence(library, items), expected)
        self.assertEqual(library['records'][0]['evidence'], [])
        self.assertEqual(add_evidence(library, []), library)
        with self.assertRaises(ValueError):
            add_evidence(library, [items[0], evidence_for(library, source_ref='unknown')])
        self.assertEqual(library['records'][0]['evidence'], [])

    def test_cli_batch_evidence_and_selected_export(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            library = one_record_library()
            source, batch, output = (folder / n for n in ('library.json', 'batch.json', 'updated.json'))
            source.write_text(json.dumps(library), encoding='utf-8')
            batch.write_text(json.dumps([evidence_for(library), evidence_for(library, claim='Second claim')]),
                             encoding='utf-8')
            base = [sys.executable, str(SCRIPTS / 'literature_pipeline.py')]
            process = subprocess.run(base + ['evidence', '--library', str(source), '--input', str(batch),
                '--output', str(output)], capture_output=True, text=True, timeout=20)
            self.assertEqual(process.returncode, 0, process.stderr)
            updated = json.loads(output.read_text(encoding='utf-8'))
            self.assertEqual(len(updated['records'][0]['evidence']), 2)
            exports = folder / 'exports'
            process = subprocess.run(base + ['export', '--library', str(output), '--output-dir', str(exports),
                '--only', 'references.bib', 'evidence.csv'], capture_output=True, text=True, timeout=20)
            self.assertEqual(process.returncode, 0, process.stderr)
            self.assertEqual({p.name for p in exports.iterdir()}, {'references.bib', 'evidence.csv'})
            self.assertEqual(len(list(csv.DictReader(io.StringIO((exports / 'evidence.csv').read_text(encoding='utf-8'))))), 2)
            existing = (exports / 'references.bib').read_bytes()
            process = subprocess.run(base + ['export', '--library', str(output), '--output-dir', str(exports),
                '--only', 'references.bib'], capture_output=True, text=True, timeout=20)
            self.assertNotEqual(process.returncode, 0)
            self.assertEqual((exports / 'references.bib').read_bytes(), existing)

    def test_book_export_retains_publisher_isbn_and_edition(self):
        library = merge_records([{'title': 'Synthetic acoustics handbook', 'type': 'book',
                                 'publisher': 'Example Press', 'isbn': '9780000000000',
                                 'edition': '2', 'source_id': 'book-1'}])
        bib = export_library(library)['references.bib']
        self.assertIn('@book', bib)
        self.assertIn('isbn = {9780000000000}', bib)
        self.assertIn('edition = {2}', bib)
        self.assertIn('publisher = {Example Press}', bib)

    def test_normalized_export_is_not_mislabeled_as_raw_provider_metadata(self):
        item = {'title': 'Normalized-only export', 'pmid': '12345',
                'metadata_basis': 'normalized client export', 'abstract': 'Supplied abstract.'}
        source = merge_records([item])['records'][0]['sources'][0]
        self.assertIsNone(source['raw_metadata'])
        self.assertEqual(source['metadata_basis'], 'normalized_export')
        self.assertEqual(source['imported_metadata'], item)

    def test_same_provider_identity_with_conflicting_dois_is_rejected(self):
        library = one_record_library()
        with self.assertRaisesRegex(ValueError, 'Conflicting source identity'):
            merge_records([imported_record(doi='10.1234/different')], library=library)
        self.assertEqual(library['records'][0]['doi'], '10.1234/anc.1')
        self.assertEqual(len(library['records']), 1)

    def test_provider_export_identifiers_and_publication_fields_survive(self):
        library = merge_records([{
            'title': 'A conference record', 'authors': ['Li, A.'],
            'openalex_id': 'https://openalex.org/W123', 'year': 2026,
            'type': 'proceedings-article', 'journal': 'Acoustics Proceedings',
            'volume': '8', 'issue': '2', 'pages': '10-19', 'publisher': 'Example publisher',
        }])
        record_id = library['records'][0]['record_id']
        updated = merge_records([{
            'title': 'A conference record', 'openalex_id': 'https://openalex.org/W123',
            'doi': '10.1234/conf.1', 'year': 2026,
        }], library=library)
        self.assertEqual(len(updated['records']), 1)
        self.assertEqual(updated['records'][0]['record_id'], record_id)
        self.assertEqual(updated['records'][0]['sources'][0]['source'], 'openalex')
        bib = export_library(updated)['references.bib']
        self.assertIn('@inproceedings', bib)
        self.assertIn('booktitle = {Acoustics Proceedings}', bib)
        self.assertIn('volume = {8}', bib)
        self.assertIn('number = {2}', bib)
        self.assertIn('pages = {10--19}', bib)

    def test_evidence_and_decision_export_reimport_is_idempotent(self):
        library = add_evidence(one_record_library(), evidence_for(one_record_library()))
        evidence = library['records'][0]['evidence'][0]
        again = add_evidence(library, evidence)
        self.assertEqual(len(again['records'][0]['evidence']), 1)
        decision = {'record_id': library['records'][0]['record_id'], 'stage': 'title_abstract',
                    'decision': 'uncertain', 'reviewer': 'reader', 'reason': 'Needs full text'}
        library = screen_records(library, [decision])
        again = screen_records(library, [library['records'][0]['screening'][0]])
        self.assertEqual(len(again['records'][0]['screening']), 1)

    def test_doi_aliases_merge_without_losing_sources_or_title_conflicts(self):
        # Break caught: DOI aliases split records, or first-wins drops provenance.
        first = imported_record(doi="HTTPS://doi.org/10.1234/ANC.1")
        second = imported_record(
            title="An updated title for duct control",
            doi="doi:10.1234/anc.1",
            source="crossref",
            source_id="10.1234/anc.1",
            raw_metadata={"provider_marker": "crossref-proof"},
        )
        library = merge_records([first, second])
        self.assertEqual(len(library["records"]), 1)
        record = library["records"][0]
        self.assertEqual(record["doi"], "10.1234/anc.1")
        self.assertEqual(len(record["sources"]), 2)
        self.assertEqual(
            {item["source"] for item in record["sources"]},
            {"local-export", "crossref"},
        )
        observation_ids = {item["observation_id"] for item in record["sources"]}
        self.assertEqual(len(observation_ids), 2)
        for item in record["sources"]:
            self.assertTrue(
                {"observation_id", "source", "source_id", "query",
                 "retrieved_at", "raw_metadata"}.issubset(item)
            )
        conflicts = json.dumps(record["metadata_conflicts"], ensure_ascii=False)
        self.assertIn(first["title"], conflicts)
        self.assertIn(second["title"], conflicts)
        source_text = json.dumps(record["sources"], ensure_ascii=False)
        self.assertIn("local-proof", source_text)
        self.assertIn("crossref-proof", source_text)

    def test_incremental_doi_enrichment_preserves_existing_record_id(self):
        # Break caught: adding a DOI replaces an established local identity.
        initial = imported_record(doi=None)
        library = merge_records([initial])
        record_id = library["records"][0]["record_id"]
        updated = imported_record(doi="https://doi.org/10.1234/ANC.1")
        result = merge_records([updated], library=library)
        self.assertEqual(len(result["records"]), 1)
        self.assertEqual(result["records"][0]["record_id"], record_id)
        self.assertEqual(result["records"][0]["doi"], "10.1234/anc.1")

    def test_equal_titles_with_different_dois_remain_separate_candidates(self):
        # Break caught: title equality silently erases distinct DOI reports.
        library = merge_records([
            imported_record(),
            imported_record(doi="10.1234/anc.2", source_id="export-002"),
        ])
        self.assertEqual(len(library["records"]), 2)
        self.assertEqual(
            {record["doi"] for record in library["records"]},
            {"10.1234/anc.1", "10.1234/anc.2"},
        )
        self.assertTrue(library["candidate_duplicates"])

    def test_missing_titles_do_not_collapse_distinct_metadata(self):
        # Break caught: empty-string fallback merges all untitled records.
        library = merge_records([
            imported_record(
                title="", doi=None, source_id="untitled-a",
                authors=["Li, A."], year=2025, abstract="Duct experiment.",
            ),
            imported_record(
                title="", doi=None, source_id="untitled-b",
                authors=["Wang, C."], year=2026, abstract="Room experiment.",
            ),
        ])
        self.assertEqual(len(library["records"]), 2)
        self.assertEqual(len({r["record_id"] for r in library["records"]}), 2)

    def test_arxiv_versions_link_without_merging_the_related_journal_report(self):
        # Break caught: a newer preprint overwrites v1, or related DOI merges reports.
        library = merge_records([
            imported_record(
                doi=None, arxiv_id="2610.01234v1", source="arxiv",
                source_id="2610.01234v1", related_doi="10.1234/journal.1",
            ),
            imported_record(
                doi=None, arxiv_id="2610.01234v2", source="arxiv",
                source_id="2610.01234v2", related_doi="10.1234/journal.1",
            ),
            imported_record(
                doi="10.1234/journal.1", source="crossref",
                source_id="10.1234/journal.1",
            ),
        ])
        self.assertEqual(len(library["records"]), 2)
        preprints = [r for r in library["records"] if r.get("arxiv_id")]
        self.assertEqual(len(preprints), 1)
        self.assertEqual(preprints[0]["arxiv_id"], "2610.01234")
        self.assertEqual(len(preprints[0]["arxiv_versions"]), 2)
        self.assertEqual(len(preprints[0]["sources"]), 2)
        journals = [r for r in library["records"]
                    if r.get("doi") == "10.1234/journal.1"]
        self.assertEqual(len(journals), 1)
        self.assertNotEqual(preprints[0]["record_id"], journals[0]["record_id"])

    def test_replaying_batch_and_evidence_does_not_duplicate_observations(self):
        # Break caught: repeated local import grows provenance or evidence forever.
        batch = [
            imported_record(),
            imported_record(
                source="crossref", source_id="10.1234/anc.1",
                raw_metadata={"provider_marker": "crossref-proof"},
            ),
        ]
        library = merge_records(batch)
        item = evidence_for(library)
        library = add_evidence(library, item)
        library = add_evidence(library, item)
        result = merge_records(batch, library=library)
        self.assertEqual(len(result["records"]), 1)
        self.assertEqual(len(result["records"][0]["sources"]), 2)
        self.assertEqual(len(result["records"][0]["evidence"]), 1)
        self.assertEqual(
            result["records"][0]["record_id"], library["records"][0]["record_id"]
        )

    def test_load_payload_keeps_search_context_and_incomplete_coverage(self):
        # Break caught: a capped export is presented as a complete search.
        records, context = load_payload({
            "results": [imported_record()],
            "query": "active noise control",
            "source": "arxiv",
            "retrieved_at": "2026-11-02T08:00:00+08:00",
            "total_available": 100,
            "complete": False,
        })
        self.assertEqual(len(records), 1)
        self.assertEqual(context["total_available"], 100)
        self.assertIs(context["complete"], False)
        self.assertEqual(context["query"], "active noise control")
        library = merge_records(records, context=context)
        search_text = json.dumps(library["searches"], ensure_ascii=False)
        self.assertIn("active noise control", search_text)
        self.assertIn("false", search_text.lower())
        normalized, _ = load_payload([imported_record()])
        self.assertEqual(len(normalized), 1)

    def test_provider_envelopes_are_rejected_instead_of_becoming_empty_records(self):
        # Break caught: a raw API response is mistaken for a normalized paper.
        raw_crossref = {
            "status": "ok",
            "message-type": "work-list",
            "message": {"items": [{"DOI": "10.1234/anc.1"}]},
        }
        with self.assertRaises((ValueError, TypeError)):
            load_payload(raw_crossref)
        with self.assertRaises((ValueError, TypeError)):
            merge_records(raw_crossref)
        with self.assertRaises((ValueError, TypeError)):
            merge_records([raw_crossref])

    def test_abstract_evidence_keeps_its_actual_source_and_level(self):
        # Break caught: evidence is detached from the source or promoted to full text.
        library = one_record_library()
        item = evidence_for(library)
        result = add_evidence(library, item)
        evidence = result["records"][0]["evidence"]
        self.assertEqual(len(evidence), 1)
        self.assertEqual(evidence[0]["source_ref"], item["source_ref"])
        self.assertEqual(evidence[0]["basis"], "abstract")
        self.assertEqual(evidence[0]["finding"], item["finding"])
        self.assertEqual(evidence[0]["locator"], item["locator"])

    def test_evidence_rejects_unavailable_full_text_pages_and_unknown_sources(self):
        # Break caught: evidence claims a page or source that was never available.
        with tempfile.TemporaryDirectory() as temporary:
            missing = str(Path(temporary) / "never-retrieved.txt")
            invalid_changes = [
                {"locator": "page 3", "basis": "abstract"},
                {"basis": "full_text", "locator": "Section 2",
                 "document_path": missing},
                {"source_ref": "observation-that-was-never-imported"},
            ]
            for changes in invalid_changes:
                with self.subTest(changes=changes):
                    library = one_record_library()
                    with self.assertRaises((ValueError, FileNotFoundError)):
                        add_evidence(library, evidence_for(library, **changes))

    def test_local_full_text_evidence_records_the_real_file_digest(self):
        # Break caught: local full text lacks a reproducible file identity.
        content = b"Section 2\nA synthetic duct test description.\n"
        expected_digest = hashlib.sha256(content).hexdigest()
        with tempfile.TemporaryDirectory() as temporary:
            document = Path(temporary) / "paper.txt"
            document.write_bytes(content)
            library = one_record_library()
            result = add_evidence(library, evidence_for(
                library, basis="full_text", locator="Section 2, sentence 1",
                document_path=str(document),
                finding="A synthetic duct test description.",
            ))
            evidence = result["records"][0]["evidence"]
            self.assertEqual(len(evidence), 1)
            self.assertEqual(evidence[0]["basis"], "full_text")
            self.assertIn(expected_digest, json.dumps(evidence).lower())

    def test_screening_preserves_the_single_reviewer_without_fabricating_review(self):
        # Break caught: software invents a second independent reviewer.
        library = one_record_library()
        record_id = library["records"][0]["record_id"]
        result = screen_records(library, [{
            "record_id": record_id,
            "stage": "title_abstract",
            "decision": "uncertain",
            "reviewer": "solo-reviewer",
            "reason": "The abstract does not report the measurement conditions.",
        }])
        history = result["records"][0]["screening"]
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["reviewer"], "solo-reviewer")
        self.assertEqual(history[0]["stage"], "title_abstract")
        self.assertEqual(history[0]["decision"], "uncertain")

    def test_exclusion_requires_a_reason_and_not_retrieved_remains_distinct(self):
        # Break caught: undocumented exclusion or unavailable text counted as reviewed.
        library = one_record_library()
        record_id = library["records"][0]["record_id"]
        with self.assertRaises(ValueError):
            screen_records(library, [{
                "record_id": record_id, "stage": "full_text",
                "decision": "exclude", "reviewer": "solo-reviewer", "reason": "",
            }])
        result = screen_records(library, [{
            "record_id": record_id, "stage": "full_text",
            "decision": "not_retrieved", "reviewer": "solo-reviewer",
            "reason": "Only a title and abstract were supplied.",
        }])
        self.assertEqual(
            result["records"][0]["screening"][-1]["decision"], "not_retrieved"
        )

    def test_exports_keep_distinct_reports_stable_keys_and_evidence_uncertainty(self):
        # Break caught: export loses a report, protected title case, or evidence limits.
        library = merge_records([
            imported_record(),
            imported_record(doi="10.1234/anc.2", source_id="export-002"),
        ], context={
            "query": "active noise control", "source": "local-export",
            "retrieved_at": "2026-11-02T08:00:00+08:00",
            "total_available": 100, "complete": False,
        })
        library = add_evidence(library, evidence_for(library))
        library = screen_records(library, [{
            "record_id": library["records"][0]["record_id"],
            "stage": "title_abstract", "decision": "uncertain",
            "reviewer": "solo-reviewer", "reason": "Full text is unavailable.",
        }])
        exports = export_library(library)
        required = {
            "records.csv", "evidence.csv", "review-map.md",
            "references.bib", "search-log.json", "screening.csv",
        }
        self.assertTrue(required.issubset(exports))
        self.assertTrue(all(isinstance(exports[name], str) for name in required))
        record_ids = {r["record_id"] for r in library["records"]}
        csv_records = list(csv.DictReader(io.StringIO(exports["records.csv"])))
        self.assertEqual(len(csv_records), 2)
        self.assertEqual({r["record_id"] for r in csv_records}, record_ids)
        bib = exports["references.bib"]
        keys = set(re.findall(r"@\w+\s*\{\s*([^,\s]+)\s*,", bib))
        self.assertEqual(keys, record_ids)
        self.assertIn("10.1234/anc.1", bib)
        self.assertIn("10.1234/anc.2", bib)
        self.assertIn("{FFT}", bib)
        self.assertEqual(
            set(re.findall(
                r"@\w+\s*\{\s*([^,\s]+)\s*,",
                export_library(merge_records([], library=library))["references.bib"],
            )), keys,
        )
        evidence_rows = list(csv.DictReader(io.StringIO(exports["evidence.csv"])))
        self.assertEqual(len(evidence_rows), 1)
        self.assertIn(
            "The abstract describes a duct evaluation.",
            json.dumps(evidence_rows),
        )
        screening_rows = list(csv.DictReader(io.StringIO(exports["screening.csv"])))
        self.assertEqual(len(screening_rows), 1)
        self.assertIn("uncertain", json.dumps(screening_rows).lower())
        markdown = exports["review-map.md"].lower()
        self.assertTrue(any(term in markdown for term in ("abstract", "摘要")))
        self.assertTrue(any(term in markdown for term in ("uncertain", "不确定")))
        self.assertIn(library["records"][0]["record_id"], markdown)
        search_log = json.loads(exports["search-log.json"])
        self.assertIn("active noise control", json.dumps(search_log))
        self.assertIn("false", json.dumps(search_log).lower())

    def test_cli_merge_refuses_to_overwrite_existing_output_by_default(self):
        # Break caught: an ordinary update destroys an existing user artifact.
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            incoming = directory / "incoming.json"
            destination = directory / "existing-library.json"
            incoming.write_text(json.dumps([imported_record()]), encoding="utf-8")
            preserved_bytes = b"existing content must survive\n"
            destination.write_bytes(preserved_bytes)
            process = subprocess.run(
                [
                    sys.executable, str(SCRIPTS / "literature_pipeline.py"),
                    "merge", "--input", str(incoming), "--output", str(destination),
                ],
                capture_output=True, text=True, timeout=20, check=False,
            )
            self.assertNotEqual(process.returncode, 0)
            self.assertEqual(destination.read_bytes(), preserved_bytes)


if __name__ == "__main__":
    unittest.main()
