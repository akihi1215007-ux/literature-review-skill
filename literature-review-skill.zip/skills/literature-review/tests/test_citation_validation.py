"""Offline regressions for citation parsing and truthful validation reports."""
import contextlib
import importlib.util
import io
from pathlib import Path
import sys
import tempfile
import unittest


TOOLS = Path(__file__).resolve().parents[1] / "scripts" / "citation_tools"
sys.path.insert(0, str(TOOLS))
from _common import parse_bibtex, render_entry


class BibtexParsingTests(unittest.TestCase):
    def test_malformed_tail_never_returns_a_successful_prefix(self):
        source = '@misc{good, title={Good}, year={2024}}\n@article{broken, title={Open}'
        with self.assertRaises(ValueError):
            parse_bibtex(source)

    def test_round_entry_ignores_parentheses_inside_braced_values(self):
        entries = parse_bibtex('@misc(key, title={Right ) bracket}, year=2024)')
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["fields"], {"title": "Right ) bracket", "year": "2024"})

    def test_nested_and_quoted_delimiters_preserve_complete_values(self):
        cases = (
            ('@misc{k, title="Right } bracket, and {nested}", year=2024}',
             'Right } bracket, and {nested}'),
            ('@misc(k, title="Right ) bracket, and {nested}", year=2024)',
             'Right ) bracket, and {nested}'),
            (r'@misc{k, title={Nested {A, B} and \{literal\}}, year=2024}',
             r'Nested {A, B} and \{literal\}'),
            (r'@misc{k, title="A \"quoted\" title, continued", year=2024}',
             r'A \"quoted\" title, continued'),
        )
        for source, title in cases:
            with self.subTest(source=source):
                self.assertEqual(parse_bibtex(source)[0]["fields"]["title"], title)

    def test_malformed_fields_and_unsupported_concatenation_fail_explicitly(self):
        for source in (
            '@misc{k, title={Fine}, broken}',
            '@misc{k, title={Fine} year=2024}',
            '@misc{k, title="Unclosed}',
            '@misc{k, title={First} # {Second}}',
            '@misc{k, title={Fine}, year=}',
            '@misc{, title={No key}}',
            '@misc{k, title={Fine},, year=2024}',
        ):
            with self.subTest(source=source), self.assertRaises(ValueError):
                parse_bibtex(source)

    def test_renderer_output_keeps_public_entry_shape_and_raw_source(self):
        source = render_entry("article", "Smith2024paper", {
            "author": "Smith, Ada", "title": "A {GPU} study", "year": "2024", "journal": "J"
        })
        self.assertEqual(parse_bibtex(source), [{
            "type": "article", "key": "Smith2024paper",
            "fields": {"author": "Smith, Ada", "title": "A {GPU} study", "journal": "J", "year": "2024"},
            "raw": source,
        }])

    def test_braced_metadata_preserves_literal_unpaired_quote(self):
        source = render_entry("misc", "screen", {"title": 'A 12" display', "year": "2024"})
        self.assertEqual(parse_bibtex(source)[0]["fields"]["title"], 'A 12" display')

    def test_quoted_values_preserve_brace_protected_quotes_and_commas(self):
        for title in ('A {"quoted"} title', 'A {"quoted, phrase"} title'):
            with self.subTest(title=title):
                source = '@misc{k, title="' + title + '", year=2024}'
                self.assertEqual(parse_bibtex(source)[0]["fields"], {"title": title, "year": "2024"})

    def test_comment_block_ignores_literal_quote_before_next_entry(self):
        entries = parse_bibtex('@comment{A 12" display}\n@misc{k,title={Valid},year=2024}')
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["key"], "k")
        self.assertEqual(entries[0]["fields"], {"title": "Valid", "year": "2024"})


@unittest.skipUnless(importlib.util.find_spec("requests"), "citation validator requires requests")
class CitationValidationTests(unittest.TestCase):
    def setUp(self):
        from validate_citations import CitationValidator
        self.validator = CitationValidator()
        self.addCleanup(self.validator.session.close)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.bib = self.root / "references.bib"
        self.bib.write_text('@misc{good, title={Good}, year=2024}', encoding="utf-8")

    def manuscript(self, text, suffix=".md"):
        path = self.root / ("manuscript" + suffix)
        path.write_text(text, encoding="utf-8")
        return path

    def validate(self, **kwargs):
        with contextlib.redirect_stderr(io.StringIO()):
            return self.validator.validate_file(str(self.bib), **kwargs)

    def test_latex_commands_optional_arguments_and_multiple_keys(self):
        path = self.manuscript(r"""
\citep[see][pp. 2--4]{alpha, beta}
\textcite{gamma} \parencite*[p. 5]{delta, epsilon}
\autocite[compare][chapter 3]{zeta} \cite{eta}
""", ".tex")
        self.assertEqual(set(self.validator.parse_manuscript_citations(str(path))),
                         {"alpha", "beta", "gamma", "delta", "epsilon", "zeta", "eta"})

    def test_pandoc_period_in_key_and_sentence_punctuation(self):
        path = self.manuscript("See [@foo.bar; @second-key] and @plain. Contact a.user@example.com.")
        self.assertEqual(set(self.validator.parse_manuscript_citations(str(path))),
                         {"foo.bar", "second-key", "plain"})

    def test_comments_code_and_email_do_not_create_citations(self):
        path = self.manuscript(r"""
[@real]
<!-- @html \cite{htmltex} -->
`@inline` and ``\cite{inline_latex}``
```latex
@fenced \cite{fenced_latex}
```
~~~
@tilde
~~~
\begin{verbatim}
\cite{verbatim} @verbatimmd
\end{verbatim}
\verb|@verb| user@example.com
""")
        self.assertEqual(set(self.validator.parse_manuscript_citations(str(path))), {"real"})

    def test_latex_comments_are_excluded_but_markdown_percent_is_literal(self):
        latex = self.manuscript("% \\cite{comment}\n\\cite{real}", ".tex")
        self.assertEqual(set(self.validator.parse_manuscript_citations(str(latex))), {"real"})
        markdown = self.manuscript("95% coverage [@real]")
        self.assertEqual(set(self.validator.parse_manuscript_citations(str(markdown))), {"real"})

    def test_unsupported_latex_citation_syntax_is_explicitly_unchecked(self):
        for source in (r'\citep[see [nested]]{good}', r'\cites{good}{second}', r'\cite{good'):
            with self.subTest(source=source):
                path = self.manuscript(source, ".tex")
                with self.assertRaises(ValueError):
                    self.validator.parse_manuscript_citations(str(path))
                report = self.validate(manuscript_filepath=str(path))
                self.assertFalse(report["manuscript_results"]["checked"])
                self.assertIn("manuscript_parse_error", {error["type"] for error in report["errors"]})
                self.assertEqual(report["manuscript_results"]["unused_keys"], [])

    def test_missing_and_undecodable_manuscript_raise_read_error(self):
        bad = self.root / "bad.md"
        bad.write_bytes(b"\xff\xfe\x80")
        for path in (self.root / "absent.md", bad):
            with self.subTest(path=path), self.assertRaises((OSError, UnicodeError)):
                self.validator.parse_manuscript_citations(str(path))

    def test_unreadable_manuscript_is_not_reported_as_checked_or_unused(self):
        bad = self.root / "bad.md"
        bad.write_bytes(b"\xff\xfe\x80")
        for path in (self.root / "absent.md", bad):
            with self.subTest(path=path):
                report = self.validate(manuscript_filepath=str(path), min_count=1)
                self.assertFalse(report["manuscript_results"]["checked"])
                self.assertIn("manuscript_read_error", {error["type"] for error in report["errors"]})
                self.assertEqual(report["manuscript_results"]["unused_keys"], [])
                self.assertFalse(any(item["type"] == "unused_citation" for item in report["warnings"]))
                self.assertFalse(any(item["type"] == "manuscript_below_requested_minimum" for item in report["errors"]))

    def test_genuinely_empty_manuscript_is_successfully_checked(self):
        report = self.validate(manuscript_filepath=str(self.manuscript("")))
        self.assertTrue(report["manuscript_results"]["checked"])
        self.assertEqual(report["manuscript_results"]["cited_keys"], [])
        self.assertEqual(report["manuscript_results"]["unused_keys"], ["good"])
        self.assertEqual(report["errors"], [])

    def test_malformed_bibliography_report_never_claims_valid_prefix(self):
        self.bib.write_text(self.bib.read_text(encoding="utf-8") + '\n@misc{broken, title={Open}', encoding="utf-8")
        report = self.validate()
        self.assertEqual(report["valid_entries"], 0)
        self.assertIn("bibtex_parse_error", {error["type"] for error in report["errors"]})

    def test_book_requires_nonblank_author_or_editor(self):
        for names in ({}, {"author": ""}, {"author": "  ", "editor": "\t"}):
            entry = {"type": "book", "key": "book", "fields": {
                "title": "Book", "publisher": "Press", "year": "2024", **names}}
            with self.subTest(names=names):
                errors, _ = self.validator.validate_entry(entry)
                self.assertTrue(any(error.get("field") == "author or editor" for error in errors))

    def test_book_accepts_author_or_editor_alone(self):
        for names in ({"author": "Ada Smith"}, {"author": "", "editor": "Ada Smith"}):
            entry = {"type": "book", "key": "book", "fields": {
                "title": "Book", "publisher": "Press", "year": "2024", **names}}
            with self.subTest(names=names):
                errors, _ = self.validator.validate_entry(entry)
                self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
